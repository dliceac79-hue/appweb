<?php
// === CONFIGURACIÓN ===
// Cambia estas constantes con tus datos de MySQL en Neubox/cPanel.
define('DB_HOST', 'localhost');
define('DB_NAME', 'amtgloba_logiops');       // o el nombre que creaste
define('DB_USER', 'amtgloba_dliceac79');
define('DB_PASS', '@Licd791212jm4');

define('APP_NAME', 'Lites Logistics, LLC');
// Si subes a /public_html/logiops/ usa '/logiops/'
define('BASE_URL', '/logiops/logis_app/');

date_default_timezone_set('America/Monterrey');
