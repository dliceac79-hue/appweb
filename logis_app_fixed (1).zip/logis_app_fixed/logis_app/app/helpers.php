<?php
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function badge_status($s){
  $map=[ 'draft'=>'secondary','booked'=>'info','in_transit'=>'warning','delivered'=>'success','cancelled'=>'danger',
         'issued'=>'info','paid'=>'success'];
  $c=$map[$s]??'secondary'; return '<span class="badge bg-'.$c.' text-capitalize">'.$s.'</span>';
}
