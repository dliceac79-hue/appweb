<?php
$pdo=db();
$rows=$pdo->query("SELECT * FROM providers ORDER BY provider_id DESC LIMIT 200")->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Proveedores</h1>
  <a class="btn btn-primary" href="<?= BASE_URL ?>public/index.php?p=providers_new">+ Nuevo proveedor</a>
</div>
<div class="card p-3">
<div class="table-responsive"><table class="table align-middle">
<thead><tr><th>ID</th><th>Nombre</th><th>Tipo</th><th>Contacto</th><th>Teléfono</th><th>Email</th><th>Días</th><th>Límite</th><th></th></tr></thead>
<tbody>
<?php foreach($rows as $r): ?>
<tr>
  <td>#<?= (int)$r['provider_id'] ?></td>
  <td><?= e($r['name']) ?></td>
  <td><?= e($r['tipo']) ?></td>
  <td><?= e($r['contact_name']) ?></td>
  <td><?= e($r['phone']) ?></td>
  <td><?= e($r['email']) ?></td>
  <td style="text-align:center;"><?= (int)($r['credit_days'] ?? 0) ?></td>
  <td style="text-align:right;">&dollar;<?= number_format((float)($r['credit_limit'] ?? 0),2) ?></td>
  <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=providers_edit&id=<?= (int)$r['provider_id'] ?>">Editar</a></td>
</tr>
<?php endforeach; if(!$rows): ?><tr><td colspan="9" class="text-center text-muted">Sin proveedores.</td></tr><?php endif; ?>
</tbody></table></div></div>
