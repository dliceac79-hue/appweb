<?php
$pdo=db();
$rows=$pdo->query("SELECT i.invoice_id,i.invoice_number,i.issue_date,i.due_date,i.total,i.amount_paid,i.status,c.name AS client
FROM invoices i LEFT JOIN clients c ON c.client_id=i.client_id
ORDER BY i.invoice_id DESC LIMIT 200")->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Facturas</h1>
  <a class="btn btn-primary" href="<?= BASE_URL ?>public/index.php?p=invoices_new">+ Nueva factura</a>
</div>
<div class="card p-3">
<div class="table-responsive">
<table class="table align-middle">
  <thead><tr><th>ID</th><th>Cliente</th><th>Emisión</th><th>Vencimiento</th><th>Total</th><th>Pagado</th><th>Status</th></tr></thead>
  <tbody>
    <?php foreach($rows as $r): ?>
    <tr>
      <td>#<?= (int)$r['invoice_id'] ?></td>
      <td><?= e($r['client']) ?></td>
      <td><?= e($r['issue_date']) ?></td>
      <td><?= e($r['due_date']) ?></td>
      <td class="text-end">$<?= number_format($r['total'],2) ?></td>
      <td class="text-end">$<?= number_format($r['amount_paid'],2) ?></td>
      <td><?= badge_status($r['status']) ?></td>
    </tr>
    <?php endforeach; if(!$rows): ?>
    <tr><td colspan="7" class="text-center text-muted">Sin facturas.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</div>
</div>
