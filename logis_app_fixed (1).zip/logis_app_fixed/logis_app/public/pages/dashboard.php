<?php
$pdo=db();

$total_clients = (int)($pdo->query("SELECT COUNT(*) c FROM clients")->fetch()['c'] ?? 0);
$total_prov    = (int)($pdo->query("SELECT COUNT(*) c FROM providers")->fetch()['c'] ?? 0);
$total_ship    = (int)($pdo->query("SELECT COUNT(*) c FROM shipments")->fetch()['c'] ?? 0);
$in_transit    = (int)($pdo->query("SELECT COUNT(*) c FROM shipments WHERE status='in_transit'")->fetch()['c'] ?? 0);
$delivered     = (int)($pdo->query("SELECT COUNT(*) c FROM shipments WHERE status='delivered'")->fetch()['c'] ?? 0);

$inv_month = (float)($pdo->query("""
  SELECT COALESCE(SUM(total),0) t FROM invoices
  WHERE DATE_FORMAT(issue_date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')
""")->fetch()['t'] ?? 0);

$recent = $pdo->query("""
  SELECT s.shipment_id, s.reference, s.status, s.pickup_date, s.delivery_date,
         c.name AS client_name
  FROM shipments s
  LEFT JOIN clients c ON c.client_id=s.client_id
  ORDER BY s.shipment_id DESC LIMIT 8
""")->fetchAll();
?>
<h1 class="page-title mb-4">Dashboard</h1>
<div class="row g-4 mb-4">
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">Clientes</div><div class="display-6"><?= $total_clients ?></div></div></div>
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">Proveedores</div><div class="display-6"><?= $total_prov ?></div></div></div>
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">Envíos</div><div class="display-6"><?= $total_ship ?></div></div></div>
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">En tránsito</div><div class="display-6"><?= $in_transit ?></div></div></div>
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">Entregados</div><div class="display-6"><?= $delivered ?></div></div></div>
  <div class="col-md-2"><div class="card p-4"><div class="h6 text-muted">Facturado (mes)</div><div class="display-6">$<?= number_format($inv_month,2) ?></div></div></div>
</div>
<div class="card p-3">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <strong>Últimos envíos</strong>
    <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>public/index.php?p=shipments">Ver todos</a>
  </div>
  <div class="table-responsive">
  <table class="table align-middle">
    <thead><tr><th>ID</th><th>Referencia</th><th>Cliente</th><th>Status</th><th>Pickup</th><th>Entrega</th></tr></thead>
    <tbody>
      <?php foreach($recent as $r): ?>
      <tr>
        <td>#<?= (int)$r['shipment_id'] ?></td>
        <td><?= e($r['reference']) ?></td>
        <td><?= e($r['client_name']) ?></td>
        <td><?= badge_status($r['status']) ?></td>
        <td><?= e($r['pickup_date']) ?></td>
        <td><?= e($r['delivery_date']) ?></td>
      </tr>
      <?php endforeach; if(!$recent): ?>
      <tr><td colspan="6" class="text-center text-muted">Sin envíos.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>
