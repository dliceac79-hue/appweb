<?php
$pdo=db(); $err=''; $ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??''); $tipo=$_POST['tipo']??''; $contact=$_POST['contact_name']??'';
  $email=$_POST['email']??''; $phone=$_POST['phone']??''; $notes=$_POST['notes']??'';
  $credit_days=(int)($_POST['credit_days']??0); $credit_limit=(float)($_POST['credit_limit']??0);
  if($name===''){ $err='El nombre es obligatorio.'; }
  if($credit_days<0){ $err='Días de crédito no puede ser negativo.'; }
  if($credit_limit<0){ $err='Límite de crédito no puede ser negativo.'; }
  if(!$err){
    $st=$pdo->prepare("INSERT INTO providers (name,tipo,contact_name,email,phone,notes,credit_days,credit_limit) VALUES (?,?,?,?,?,?,?,?)");
    $st->execute([$name,$tipo,$contact,$email,$phone,$notes,$credit_days,$credit_limit]); $ok='Proveedor creado.';
  }
}
?>
<h1 class="page-title mb-3">Nuevo proveedor</h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<?php if($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<form method="post" class="card p-4">
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Nombre*</label><input class="form-control" name="name" required></div>
    <div class="col-md-3"><label class="form-label">Tipo</label><input class="form-control" name="tipo"></div>
    <div class="col-md-3"><label class="form-label">Contacto</label><input class="form-control" name="contact_name"></div>
    <div class="col-md-4"><label class="form-label">Email</label><input class="form-control" type="email" name="email"></div>
    <div class="col-md-4"><label class="form-label">Teléfono</label><input class="form-control" name="phone"></div>
    <div class="col-12"><label class="form-label">Notas</label><textarea class="form-control" name="notes"></textarea></div>
    <div class="col-md-3"><label class="form-label">Días de crédito</label><input class="form-control" type="number" step="1" name="credit_days" value="0"></div>
    <div class="col-md-3"><label class="form-label">Límite de crédito</label><input class="form-control" type="number" step="0.01" name="credit_limit" value="0"></div>
  </div>
  <div class="mt-3"><button class="btn btn-primary">Crear</button>
  <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=providers">Volver</a></div>
</form>
